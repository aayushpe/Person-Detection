# Person detection > 2024-11-20 9:24pm
https://universe.roboflow.com/test-tqu9c/person-detection-5xfmj

Provided by a Roboflow user
License: CC BY 4.0

